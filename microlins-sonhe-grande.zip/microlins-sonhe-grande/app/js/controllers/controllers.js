(function () {
    'use strict';

    angular
        .module('SonheGrande')
        .controller('SonheGrandeCtrl', SonheGrandeCtrl)
        .controller('HeaderCtrl', HeaderCtrl)
        .controller('HomeCtrl', HomeCtrl)
        .controller("ModalCtrl", ModalCtrl)
        .controller('CadastroCtrl', CadastroCtrl)
        .controller('CadastroSenhaCtrl', CadastroSenhaCtrl)
        .controller('ImagemUploadCtrl', ImagemUploadCtrl)
        .controller('EnviarEstampaCtrl', EnviarEstampaCtrl)
        .controller('MinhaContaCtrl', MinhaContaCtrl)
        .controller('ConclusaoCtrl', ConclusaoCtrl)
        .controller('LoginCtrl', LoginCtrl)
        .controller('RedefinirSenhaCtrl', RedefinirSenhaCtrl)
        .controller('VerEstampasCtrl', VerEstampasCtrl)
        .controller('VotoInternoCtrl', VotoInternoCtrl)


    /** @ngInject */
    function SonheGrandeCtrl() {
        var vm = this;

        init();

        function init() {}

    }

    function HeaderCtrl($state, $localStorage) {
        var vm = this;

        init();

        function init() {
            vm.state = $state.current.name;
            vm.logado = ($localStorage.cadastro) ? $localStorage.cadastro.id : 0;
            vm.nome = ($localStorage.cadastro) ? $localStorage.cadastro.nome.split(/\s(.+)/)[0] : '';
            vm.imgProfile = ($localStorage.cadastro) ? $localStorage.cadastro.foto : null;
        }

        vm.logout = function (params) {
            delete $localStorage.cadastro;
            vm.state == 'home' ? $state.reload() : $state.go('home');
        }

    }

    function ModalCtrl($state, $rootScope) {
        var vm = this;

        init();

        function init() {}

        $rootScope.modalSonheGrande = {};
        $rootScope.modalSonheGrande.open = 0;

        vm.openModal = function (params) {
            $rootScope.modalSonheGrande.open = 1;
            $rootScope.modalSonheGrande.tipo = params;
        }

        vm.closeModal = function () {
            $rootScope.modalSonheGrande.open = 0;
        }

    }

    function HomeCtrl($location, $scope, $rootScope, $facebook) {
        var vm = this;

        init();

        function init() {
            if ($location.$$search.v) {
                $rootScope.gotoArea('call-to-stamp-voting');
            }

            vm.compartilhar = function (codigo) {

                $facebook.ui({
                    method: 'share',
                    mobile_iframe: true,
                    href: 'https://www.sonhegrandemicrolins.com.br',
                }).then(function (ret) {

                });

            }
        }

    }

    function CadastroCtrl(SSO, ngXml2json, API, $state, $localStorage, $rootScope, SweetAlert) {
        var vm = this;

        init();

        function init() {

            vm.logado = ($localStorage.cadastro) ? $localStorage.cadastro.id : 0;

            if (vm.logado && $state.current.name == 'cadastro') {
                $state.go('enviar-estampa');
            }

            vm.loading = false;

            vm.uni = [];
            vm.uniModal = [];

            var url = "Estados.asmx/RetornaEstadosPorMarca?SenhaAplicacao=SCO3W1ZVN30VOHVKTQWQ&MarcaID=5";

            SSO.get(url).then(function name(ret) {
                var jsonObject = ngXml2json.parser(ret);
                vm.itemEstados = jsonObject.arrayofestadosmdl.estadosmdl;
                vm.carregaUnidades = false;
            });
        }

        vm.onSelectEstadoCallback = function (item) {

            vm.uni.cidade = undefined;
            vm.uni.unidade = undefined;
            vm.uniModal.cidade = undefined;
            vm.uniModal.unidade = undefined;
            vm.alunoUnidade = undefined;

            vm.loading = 'CARREGANDO CIDADES';

            vm.itemCidades = [{
                nome: 'CARREGANDO CIDADES',
                id: 0
            }];

            vm.itemUnidades = [{
                nomefantasia: 'ESCOLHA UMA CIDADE',
                id: 0
            }];

            var url = "Cidades.asmx/RetornaCidadesPorMarcaEstado?SenhaAplicacao=SCO3W1ZVN30VOHVKTQWQ&EstadoID=" + item.id + "&MarcaID=5";

            SSO.get(url).then(function name(ret) {
                var jsonObject = ngXml2json.parser(ret);

                var cidades = jsonObject.arrayofcidadesmdl.cidadesmdl;

                if (!Array.isArray(cidades)) {
                    cidades = [cidades];
                }

                vm.itemCidades = cidades;

                vm.loading = false;
            });
        };

        vm.onSelectCidadeCallback = function (item) {
            vm.loading = 'CARREGANDO UNIDADES';

            vm.itemUnidades = [{
                nomefantasia: 'CARREGANDO UNIDADES',
                id: 0
            }];
            vm.uni.unidade = undefined;
            vm.uniModal.unidade = undefined;
            vm.alunoUnidade = undefined;

            var url = "Unidades.asmx/RetornaUnidadesPorCidade?SenhaAplicacao=SCO3W1ZVN30VOHVKTQWQ&CidadeID=" + item.id + "&MarcaID=5";

            SSO.get(url).then(function name(ret) {
                var jsonObject = ngXml2json.parser(ret);

                var unidades = jsonObject.arrayofunidadesmdl.unidadesmdl;

                if (!Array.isArray(unidades)) {
                    unidades = [unidades];
                }

                unidades.forEach(function (value, key) {
                    if (value.nomefantasia == 'Unidade de Testes') {
                        unidades.pop(key);
                    }
                });

                vm.itemUnidades = unidades;

                vm.loading = false;
            });
        };

        vm.onSelectUnidadeCallback = function (item) {
            vm.alunoUnidade = item;
        };

        vm.closeModal = function () {
            if ($rootScope.modalSonheGrande != undefined) {
                $rootScope.modalSonheGrande.open = 0;
            }
        }

        vm.openModal = function (params) {
            $rootScope.modalSonheGrande.open = 1;
            $rootScope.modalSonheGrande.tipo = params;
        }

        vm.cadastrar = function (cad, area) {

            if (vm.cadastro.$valid) {

                if (!isCpfValido(cad.cpf)) {
                    SweetAlert.swal('Erro!', 'Informe um CPF válido para continuar.', 'error');
                    return;
                }

                vm.loading = 'Enviando dados!';

                cad.ddd = cad.telefone
                    .replace("(", "")
                    .replace(")", "")
                    .replace(" ", "")
                    .replace(" ", "")
                    .replace("-", "")
                    .substr(0, 2);

                cad.tel = cad.telefone
                    .replace("(", "")
                    .replace(")", "")
                    .replace(" ", "")
                    .replace(" ", "")
                    .replace("-", "")
                    .substr(2);

                cad.code = vm.alunoUnidade.codigoemitente;
                cad.marca = vm.alunoUnidade.marcaid;
                cad.cidade = vm.alunoUnidade.endereco.cidade;
                cad.estado = vm.alunoUnidade.endereco.estado;
                cad.unidade = vm.alunoUnidade.nomefantasia;
                cad.endereco = vm.alunoUnidade.endereco.logradouro + ' ' + vm.alunoUnidade.endereco.numero;
                cad.bairro = vm.alunoUnidade.endereco.bairro;
                cad.telUnidade = vm.alunoUnidade.telefone;

                if (Object.keys(vm.alunoUnidade.coordenadas.longitude).length > 0)
                    cad.longitude = vm.alunoUnidade.coordenadas.longitude.replace(",", ".");

                if (Object.keys(vm.alunoUnidade.coordenadas.latitude).length > 0)
                    cad.latitude = vm.alunoUnidade.coordenadas.latitude.replace(",", ".");

                delete $localStorage.cadastro;
                $localStorage.cadastro = cad;


                if (area == 'Modal') {
                    vm.closeModal();
                    vm.openModal('Senha');
                } else {
                    $state.go('cadastro-senha');
                }

            } else {

                angular.forEach(vm.cadastro.$error, function (field) {
                    angular.forEach(field, function (errorField) {
                        errorField.$setTouched();
                        errorField.$setDirty();
                    })
                });
            }

            function isCpfValido(cpf) {
                cpf = cpf.replace(/[\.-]/g, '');

                if (cpf.length >= 11) {
                    var Soma;
                    var Resto;
                    Soma = 0;
                    if (cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" ||
                        cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" ||
                        cpf == "88888888888" || cpf == "99999999999") return false;

                    for (var i = 1; i <= 9; i++) Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (11 - i);
                    Resto = (Soma * 10) % 11;

                    if ((Resto == 10) || (Resto == 11)) Resto = 0;
                    if (Resto != parseInt(cpf.substring(9, 10))) return false;

                    Soma = 0;
                    for (var i = 1; i <= 10; i++) Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (12 - i);
                    Resto = (Soma * 10) % 11;

                    if ((Resto == 10) || (Resto == 11)) Resto = 0;
                    if (Resto != parseInt(cpf.substring(10, 11))) return false;

                    return true;
                }
            }
        };
    }

    function CadastroSenhaCtrl(FileUploader, ngXml2json, API, $state, $localStorage, $facebook, $scope, $rootScope, SweetAlert) {
        var vm = this;

        init();

        function init() {
            vm.loading = false;

            if (!$localStorage.cadastro && $state.current.name == 'cadastro-senha') {
                $state.go('cadastro');
                return;
            }

            vm.cadastro = angular.copy($localStorage.cadastro);

            var uploader = vm.uploader = new FileUploader({
                url: '../api/upload-profile'
            });

            uploader.filters.push({
                name: 'syncFilter',
                fn: function (item, options) {
                    return this.queue.length < 10;
                }
            });

            uploader.filters.push({
                name: 'asyncFilter',
                fn: function (item, options, deferred) {
                    setTimeout(deferred.resolve, 1e3);
                }
            });

            uploader.filters.push({
                name: 'Extensions',
                fn: function (item, options) {
                    var allowedExtensions = ['jpg', 'png'];
                    var ext = item.name.split('.').pop();

                    return allowedExtensions.indexOf(ext) !== -1;;
                }
            });

            uploader.onWhenAddingFileFailed = function (item, filter, options) {};
            uploader.onAfterAddingFile = function (fileItem) {};
            uploader.onAfterAddingAll = function (addedFileItems) {
                uploader.uploadAll();
                vm.loading = 'Enviando imagem!';
            };
            uploader.onBeforeUploadItem = function (item) {};
            uploader.onProgressItem = function (fileItem, progress) {};
            uploader.onProgressAll = function (progress) {};
            uploader.onSuccessItem = function (fileItem, response, status, headers) {};
            uploader.onErrorItem = function (fileItem, response, status, headers) {};
            uploader.onCancelItem = function (fileItem, response, status, headers) {};
            uploader.onCompleteItem = function (fileItem, response, status, headers) {
                vm.imgProfile = response.image;
                vm.facebookid = "";
                vm.cadastro.imgProfile = response.image;
                vm.cadastro.foto = response.image;
                $localStorage.cadastro.foto = response.image;
                vm.loading = false;
            };
            uploader.onCompleteAll = function () {};

        }

        vm.cadastrar = function (cad, area) {
            vm.cadastro = angular.copy($localStorage.cadastro);
            var nArea = area;

            if (vm.formCadastro.$valid) {

                vm.loading = 'Enviando dados!';

                vm.cadastro.senha = cad.senha;
                vm.cadastro.tipoAcesso = 'senha';
                API.post('cadastrar-lead', vm.cadastro).then(function name(ret) {

                    if (ret.id > 0) {

                        vm.cadastro.id = ret.id;
                        $localStorage.cadastro.id = ret.id;
                        $localStorage.cadastro.leadId = ret.leadId;
                        $localStorage.cadastro.tipo_acesso = 'senha';

                        if (nArea == 'Modal') {
                            $rootScope.modalSonheGrande.open = 0;
                            SweetAlert.swal('Sucesso,', 'Continue votando!', 'success');
                        } else {
                            $state.go('enviar-estampa');
                        }
                    }

                    API.post('atualiza-pic-profile', vm.cadastro).then(function name(ret) {
                        $state.reload();
                    });

                    vm.loading = false;
                });
            } else {

                angular.forEach(vm.formCadastro.$error, function (field) {
                    angular.forEach(field, function (errorField) {
                        errorField.$setTouched();
                        errorField.$setDirty();
                    })
                });
            }
        };

        vm.picFace = function () {

            $facebook.login();
            $scope.$on('fb.auth.authResponseChange', function () {
                if ($facebook.isConnected()) {
                    $facebook.api('/me?fields=id,name,email,permissions').then(function (user) {

                        vm.loading = 'Enviando dados!';

                        vm.facebookid = user.id;
                        vm.imgProfile = "";

                        vm.cadastro.foto = user.id;
                        vm.cadastro.tipoAcesso = 'facebook';
                        vm.cadastro.senha = '';

                        $localStorage.cadastro.foto = user.id;
                        $localStorage.cadastro.tipo_acesso = vm.cadastro.tipoAcesso;

                        API.post('cadastrar-lead', vm.cadastro).then(function name(ret) {

                            if (ret.id > 0) {

                                $localStorage.cadastro.id = ret.id;
                                $localStorage.cadastro.leadId = ret.leadId;

                                $state.go('enviar-estampa');
                            }

                            API.post('atualiza-pic-profile', vm.cadastro).then(function name(ret) {
                                $state.reload();
                            });

                            vm.loading = false;
                        });
                    });
                }
            });
        }

    }

    function EnviarEstampaCtrl($localStorage, FileUploader, SweetAlert, API, $state) {
        var vm = this;

        init();

        function init() {

            if (!$localStorage.cadastro) {
                $state.go('cadastro');
                return;
            }

            vm.cadastro = $localStorage.cadastro;

            if (vm.cadastro.imgEstampa) {
                $state.go('conclusao');
            }
        }

        var uploader = vm.uploader = new FileUploader({
            url: '../api/upload-estampa'
        });

        uploader.filters.push({
            name: 'syncFilter',
            fn: function (item, options) {
                return this.queue.length < 10;
            }
        });

        uploader.filters.push({
            name: 'asyncFilter',
            fn: function (item, options, deferred) {
                setTimeout(deferred.resolve, 1e3);
            }
        });

        uploader.filters.push({
            name: 'Extensions',
            fn: function (item, options) {
                var allowedExtensions = ['jpg', 'png'];
                var ext = item.name.split('.').pop();

                return allowedExtensions.indexOf(ext) !== -1;;
            }
        });

        uploader.onWhenAddingFileFailed = function (item, filter, options) {};
        uploader.onAfterAddingFile = function (fileItem) {};
        uploader.onAfterAddingAll = function (addedFileItems) {
            uploader.uploadAll();
            vm.loading = 'Enviando imagem!';
        };
        uploader.onBeforeUploadItem = function (item) {};
        uploader.onProgressItem = function (fileItem, progress) {};
        uploader.onProgressAll = function (progress) {};
        uploader.onSuccessItem = function (fileItem, response, status, headers) {};
        uploader.onErrorItem = function (fileItem, response, status, headers) {};
        uploader.onCancelItem = function (fileItem, response, status, headers) {};
        uploader.onCompleteItem = function (fileItem, response, status, headers) {
            vm.imgEstampa = response.image;
            vm.facebookid = "";
            vm.cadastro.imgEstampa = response.image;
            vm.loading = false;
        };

        uploader.onCompleteAll = function () {};


        vm.cadastrar = function (cad) {

            if (vm.formEstampa.$valid) {

                vm.cadastro.nomeEstampa = cad.nome;

                $localStorage.cadastro.imgEstampa = vm.cadastro.imgEstampa ? vm.cadastro.imgEstampa : undefined;
                $localStorage.cadastro.aprovada = 0;

                vm.loading = 'Enviando dados!';

                API.post('cadastrar-estampa', vm.cadastro).then(function name(ret) {

                    if (ret > 0) {
                        $state.go('minha-conta');
                    }

                    vm.loading = false;
                });

            } else {

                angular.forEach(vm.formEstampa.$error, function (field) {
                    angular.forEach(field, function (errorField) {
                        errorField.$setTouched();
                        errorField.$setDirty();
                    })
                });

                SweetAlert.swal({
                    title: "Ops, os dados estão incompletos!",
                    text: "Por favor, preencha todos os campos.",
                    confirmButtonColor: "#d7125e",
                    type: "error",
                });
            }
        };

    }

    function ConclusaoCtrl($localStorage, FileUploader, SweetAlert, API, $state) {
        var vm = this;

        init();

        function init() {

            if (!$localStorage.cadastro) {
                $state.go('cadastro');
                return;
            }

            var cad = {};

            vm.cadastro = $localStorage.cadastro;
            cad.id = vm.cadastro.id;

            API.post('minha-conta', cad).then(function name(ret) {
                if (ret && ret.aprovada != null && ret.aprovada == 0) {
                    $state.go('minha-conta');
                }
            });

        }

    }

    function LoginCtrl($scope, $rootScope, $state, $localStorage, API, SweetAlert) {
        var vm = this;

        init();

        function init() {

        }

        vm.login = function (cad, area) {
            if (vm.formlogin.$valid && (area == 'login' || area == 'voto')) {

                vm.enviando = 1;

                API.post('login', cad).then(function name(ret) {
                    if (ret && ret.cad) {
                        $localStorage.cadastro = ret.cad;

                        if (area == 'voto') {
                            SweetAlert.swal('Login efetuado com sucesso!', 'Continue votando.', 'success');
                            vm.closeModal();
                            $state.reload();
                        } else if (ret.estampa) {
                            $localStorage.cadastro.nomeEstampa = ret.estampa.titulo;
                            $localStorage.cadastro.imgEstampa = ret.estampa.image;
                            ret.estampa.aprovada == 0 ? $state.go('conclusao') : $state.go('minha-conta');
                        } else {
                            $state.go('enviar-estampa');
                        }
                    } else {
                        SweetAlert.swal('Ops, o e-mail ou a senha estão incorretos!', 'Por favor, Tente novamente.', 'error');
                    }

                });

            } else if (cad != undefined && area == 'esqueci-minha-senha') {
                if (cad.email) {

                    cad.senha = 1;

                    API.post('login', cad).then(function name(ret) {
                        if (ret != undefined && ret.email) {
                            SweetAlert.swal({
                                title: "Quase lá",
                                text: "Um email para a redefinição da sua senha foi enviado para " + ret.email + ".",
                                type: "success"
                            });

                        } else {
                            SweetAlert.swal('Ops!', 'O e-mail informado não foi encontrado.', 'error');
                        }
                    });
                } else {
                    SweetAlert.swal('Ops!', 'O e-mail não foi preenchido corretamente.', 'error');
                }

            } else {
                SweetAlert.swal('Ops!', 'O e-mail ou a senha não foram preenchidos corretamente.', 'error');
            }
        };

        function verificaForm(form) {
            angular.forEach(form, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                    errorField.$setDirty();
                })
            });
        }

        vm.closeModal = function () {
            $rootScope.modalSonheGrande.open = 0;
        }
    }

    function RedefinirSenhaCtrl($scope, $rootScope, $state, $localStorage, API, SweetAlert) {
        var vm = this;

        init();

        function init() {}

        vm.redefinirSenha = function (cad) {

            cad.email = $state.params.email;

            if (vm.formCadastro && vm.formCadastro.$valid) {

                vm.enviando = 1;

                API.post('redefinir-senha', cad).then(function name(ret) {
                    if (ret) {
                        SweetAlert.swal({
                                confirmButtonColor: "#d43f3a",
                                confirmButtonText: "Ok!",
                                title: "Confirmado!",
                                text: "Senha alterada com sucesso!",
                                type: "success"
                            },
                            function (isConfirm) {
                                $state.go('login');
                            });
                    } else {
                        SweetAlert.swal('Email não encontrado!', 'Por favor, informe o e-mail cadastrado.', 'error');
                    }
                });

            }
        };

        function verificaForm(form) {
            angular.forEach(form, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                    errorField.$setDirty();
                })
            });
        }

    }

    function VerEstampasCtrl($state, $localStorage, $rootScope, API, SweetAlert, $facebook, $location) {
        var vm = this;

        init();

        vm.limit = 3

        function init() {
            var cad = {};
            cad.limit = 0;

            if ($state.current.name == 'home') {

                API.post('estampas-mais-votadas', cad).then(function name(ret) {

                    var str = "";

                    for (var i = 0; i < ret.length; i++) {

                        str = ret[i].nome.split(/(\s).+\s/).join("");
                        ret[i].nome = str;
                    }

                    vm.estampasVotadas = ret;
                });
            }

            if ($state.current.name == 'ver-estampas') {

                API.post('listar-estampas', cad).then(function name(ret) {

                    var str = "";

                    for (var i = 0; i < ret.length; i++) {

                        str = ret[i].nome.split(/(\s).+\s/).join("");
                        ret[i].nome = str;
                    }

                    vm.estampas = ret;
                });
            }
        }

        vm.carregar = function () {
            var cad = {};
            cad.limit = vm.limit;

            if ($state.current.name == 'home') {

                API.post('estampas-mais-votadas', cad).then(function name(ret) {

                    var str = "";

                    for (var i = 0; i < ret.length; i++) {
                        str = ret[i].nome.split(/(\s).+\s/).join("");
                        ret[i].nome = str;
                    }

                    ret.forEach(function (el, index) {
                        vm.estampasVotadas.push(el);
                    });

                    vm.limit = vm.limit + 3;
                });
            }

            if ($state.current.name == 'ver-estampas') {

                API.post('listar-estampas', cad).then(function name(ret) {

                    var str = "";

                    for (var i = 0; i < ret.length; i++) {
                        str = ret[i].nome.split(/(\s).+\s/).join("");
                        ret[i].nome = str;
                    }

                    ret.forEach(function (el, index) {
                        vm.estampas.push(el);
                    });

                    vm.limit = vm.limit + 3;
                });
            }
        }

        $rootScope.modalSonheGrande = {};
        $rootScope.modalSonheGrande.open = 0;

        vm.openModal = function (params) {
            $rootScope.modalSonheGrande.open = 1;
            $rootScope.modalSonheGrande.tipo = params;
        }

        vm.votar = function (value) {

            var cad = {}

            if ($localStorage.cadastro && $localStorage.cadastro.id) {

                API.post('votar', value).then(function name(ret) {

                    if (ret.erro) {
                        SweetAlert.swal('Ops,', 'Você já votou nessa estampa!', 'error');
                    }

                    if (ret.sucesso) {
                        value.votos++;
                        SweetAlert.swal('Sucesso,', 'Voto computado!', 'success');
                    }

                });
            } else {
                vm.openModal("Login");
            }
        }

        vm.closeModal = function () {
            $rootScope.modalSonheGrande.open = 0;
        }

        vm.compartilhar = function (codigo) {

            $facebook.ui({
                method: 'share',
                mobile_iframe: true,
                href: 'https://www.sonhegrandemicrolins.com.br/estampas/' + codigo,
            }).then(function (ret) {

            });

        }
    }

    function MinhaContaCtrl($state, $localStorage, API) {
        var vm = this;

        init();

        function init() {

            if (!$localStorage.cadastro) {
                $state.go('cadastro');
                return;
            }

            var cad = {};
            cad.id = $localStorage.cadastro.id;
            vm.cadastro = $localStorage.cadastro;

            API.post('minha-conta', cad).then(function name(ret) {
                if (ret === null) {
                    $state.go('enviar-estampa');
                } else if (ret.aprovada != null && ret.aprovada == 1) {
                    $state.go('conclusao');
                }
            });

        }

    }

    function VotoInternoCtrl($state, $localStorage, $rootScope, API, SweetAlert, $facebook, $location) {
        var vm = this;

        init();

        function init() {}

        $rootScope.modalSonheGrande = {};
        $rootScope.modalSonheGrande.open = 0;

        vm.openModal = function (params) {
            $rootScope.modalSonheGrande.open = 1;
            $rootScope.modalSonheGrande.tipo = params;
        }

        vm.votar = function (value) {

            var cad = {}
            cad.id = $('#id')[0].value;
            cad.codigo = $('#codigo')[0].value;

            if ($localStorage.cadastro && $localStorage.cadastro.id) {

                API.post('votar', cad).then(function name(ret) {

                    if (ret.erro) {
                        SweetAlert.swal('Ops,', 'Você já votou nessa estampa!', 'error');
                    }

                    if (ret.sucesso) {
                        // value.votos++;
                        var qntVotos = $('#votos').html();
                        qntVotos = parseInt(qntVotos) + 1;
                        $('#votos')[0].innerHTML = qntVotos;
                        SweetAlert.swal('Sucesso,', 'Voto computado!', 'success');
                    }

                });
            } else {
                vm.openModal("Login");
            }
        }

        vm.closeModal = function () {
            $rootScope.modalSonheGrande.open = 0;
        }
    }

    function ImagemUploadCtrl(FileUploader, ngXml2json, API, $state, $localStorage, $facebook, $scope, $rootScope, SweetAlert) {

        var vm = this;

        init();

        function init() {

            vm.loading = false;

            vm.cadastro = angular.copy($localStorage.cadastro);
            var uploader = vm.uploader = new FileUploader({
                url: '../api/upload-profile'
            });

            uploader.filters.push({
                name: 'syncFilter',
                fn: function (item, options) {
                    return this.queue.length < 10;
                }
            });

            uploader.filters.push({
                name: 'asyncFilter',
                fn: function (item, options, deferred) {
                    setTimeout(deferred.resolve, 1e3);
                }
            });

            uploader.filters.push({
                name: 'Extensions',
                fn: function (item, options) {
                    var allowedExtensions = ['jpg', 'png'];
                    var ext = item.name.split('.').pop();

                    return allowedExtensions.indexOf(ext) !== -1;;
                }
            });

            uploader.onWhenAddingFileFailed = function (item, filter, options) {};
            uploader.onAfterAddingFile = function (fileItem) {};
            uploader.onAfterAddingAll = function (addedFileItems) {
                uploader.uploadAll();
                vm.loading = 'Alterando imagem!';
            };
            uploader.onBeforeUploadItem = function (item) {};
            uploader.onProgressItem = function (fileItem, progress) {};
            uploader.onProgressAll = function (progress) {};
            uploader.onSuccessItem = function (fileItem, response, status, headers) {};
            uploader.onErrorItem = function (fileItem, response, status, headers) {};
            uploader.onCancelItem = function (fileItem, response, status, headers) {};
            uploader.onCompleteItem = function (fileItem, response, status, headers) {
                vm.imgProfile = response.image;
                vm.facebookid = "";
                vm.cadastro.foto = response.image;
                $localStorage.cadastro.foto = response.image;
                vm.loading = false;
                vm.atualizar();
            };

            uploader.onCompleteAll = function () {};
        }

        vm.atualizar = function () {

            var cad = {};

            cad = $localStorage.cadastro;

            API.post('atualiza-pic-profile', cad).then(function name(ret) {
                SweetAlert.swal("Sucesso!", "Sua imagem de perfil foi atualizada.", "success");
                vm.closeModal();
                $state.reload();
            });
        };

        vm.closeModal = function () {
            $rootScope.modalSonheGrande.open = 0;
        }
    }
}());