(function () {
    'use strict';

    angular
        .module('SonheGrande')
        .config(ConfigConfig)

    /** @ngInject */
    function ConfigConfig($stateProvider, $urlRouterProvider, $locationProvider, $facebookProvider) {

        $facebookProvider.setAppId('450419128741215').setPermissions(['email']);

        $facebookProvider.setCustomInit({
            channelUrl: '//www.sonhegrandemicrolins.com.br',
            status: true,
            cookie: true,
            xfbml: true,
        });

        $locationProvider.html5Mode(true);
        $urlRouterProvider.otherwise("/home");

        $stateProvider

            .state('home', {
                url: '/home',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@home': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@home': {
                        controller: 'HomeCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/home.html?v=' + $('body').data('versao')
                    },
                    'footer@home': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('regulamento', {
                url: '/regulamento',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@regulamento': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@regulamento': {
                        templateUrl: 'app/view/regulamento.html?v=' + $('body').data('versao')
                    },
                    'footer@regulamento': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('ver-estampas', {
                url: '/ver-estampas',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@ver-estampas': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@ver-estampas': {
                        templateUrl: 'app/view/ver-estampas.html?v=' + $('body').data('versao')
                    },
                    'footer@ver-estampas': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('cadastro', {
                url: '/cadastro',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@cadastro': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@cadastro': {
                        templateUrl: 'app/view/cadastro.html?v=' + $('body').data('versao')
                    },
                    'footer@cadastro': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('cadastro-senha', {
                url: '/cadastro-senha',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@cadastro-senha': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@cadastro-senha': {
                        templateUrl: 'app/view/cadastro-senha.html?v=' + $('body').data('versao')
                    },
                    'footer@cadastro-senha': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('carregar-estampa', {
                url: '/carregar-estampa',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@carregar-estampa': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@carregar-estampa': {
                        templateUrl: 'app/view/carregar-estampa.html?v=' + $('body').data('versao')
                    },
                    'footer@carregar-estampa': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('login', {
                url: '/login',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@login': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@login': {
                        templateUrl: 'app/view/login.html?v=' + $('body').data('versao')
                    },
                    'footer@login': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('redefinir-senha', {
                url: '/redefinir-senha/:email',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@redefinir-senha': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@redefinir-senha': {
                        templateUrl: 'app/view/redefinir-senha.html?v=' + $('body').data('versao')
                    },
                    'footer@redefinir-senha': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('conclusao', {
                url: '/conclusao',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@conclusao': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@conclusao': {
                        templateUrl: 'app/view/conclusao.html?v=' + $('body').data('versao')
                    },
                    'footer@conclusao': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('enviar-estampa', {
                url: '/enviar-estampa',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@enviar-estampa': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@enviar-estampa': {
                        templateUrl: 'app/view/enviar-estampa.html?v=' + $('body').data('versao')
                    },
                    'footer@enviar-estampa': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })

            .state('minha-conta', {
                url: '/minha-conta',
                cache: false,
                views: {
                    '@': {
                        templateUrl: 'app/view/templates/content.html?v=' + $('body').data('versao'),
                    },
                    'header@minha-conta': {
                        controller: 'HeaderCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/view/layout/header.html?v=' + $('body').data('versao')
                    },
                    'content@minha-conta': {
                        templateUrl: 'app/view/minha-conta.html?v=' + $('body').data('versao')
                    },
                    'footer@minha-conta': {
                        templateUrl: 'app/view/layout/footer.html?v=' + $('body').data('versao')
                    }
                },
                authStatus: false
            })
    }

}());