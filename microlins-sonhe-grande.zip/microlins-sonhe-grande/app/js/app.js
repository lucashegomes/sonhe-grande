(function () {
    'use strict';

    angular
        .module('SonheGrande', [
            "ngMessages",
            'oitozero.ngSweetAlert',
            'ui.bootstrap',
            "ui.router",
            "ngSanitize",
            "ngCookies",
            "angular-svg-round-progressbar",
            "ui.select",
            "ngStorage",
            "ngMask",
            "ngMap",
            "angularXml2json",
            "angularFileUpload",
            "ngFacebook"
        ])
        .config(config)
        .run(RunRun)

    /** @ngInject */
    function config() {}

    function RunRun($rootScope, $state, $window, $location, $cookies) {

        $rootScope.midiaId = $cookies.get('referer') || '';

        (function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {
                return;
            }
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/pt_BR/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-1116640-43', 'auto');

        $rootScope.styleMap = [{
                featureType: 'landscape',
                elementType: 'all',
                stylers: [{
                    color: '#f9f9f7'
                }]
            },
            {
                featureType: 'poi',
                elementType: 'geometry',
                stylers: [{
                        color: '#f9f9f7'
                    },
                    {
                        visibility: 'on'
                    }
                ]
            },
            {
                featureType: 'road.arterial',
                elementType: 'geometry',
                stylers: [{
                        color: '#d3d3d3'
                    },
                    {
                        visibility: 'on'
                    }
                ]
            },
            {
                featureType: 'all',
                elementType: 'labels.text',
                stylers: [{
                        visibility: 'on'
                    },
                    {
                        color: '#999999'
                    }
                ]
            },
            {
                featureType: 'all',
                elementType: 'labels.text.fill',
                stylers: [{
                    visibility: 'simplified'
                }]
            },
            {
                featureType: 'road.highway',
                elementType: 'geometry',
                stylers: [{
                        color: '#c4c4c4'
                    },
                    {
                        visibility: 'on'
                    }
                ]
            },
            {
                featureType: 'road.local',
                elementType: 'geometry',
                stylers: [{
                        color: '#e9e9e9'
                    },
                    {
                        visibility: 'on'
                    }
                ]
            },
            {
                featureType: 'road.local',
                elementType: 'geometry',
                stylers: [{
                        color: '#e9e9e9'
                    },
                    {
                        visibility: 'on'
                    }
                ]
            },
            {
                featureType: 'transit',
                elementType: 'labels',
                stylers: [{
                    visibility: 'off'
                }]
            },
            {
                featureType: 'poi',
                elementType: 'labels',
                stylers: [{
                    visibility: 'simplified'
                }]
            }
        ]

        $rootScope.$on('$locationChangeStart', function (event) {
            $window.scrollTo(0, 0);
            $window.ga('send', 'pageview', {
                page: $location.url()
            });
        });

        $rootScope.gotoArea = function (area) {
            $rootScope.menu = area;
            $rootScope.controlMenu = false;

            $('html, body').animate({
                scrollTop: $('#' + area).offset().top + 100
            }, 500, function () {});

        };
    }

}());