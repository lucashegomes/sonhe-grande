(function () {
    'use strict';

    angular
        .module('SonheGrande')
        .directive('uniqueCpf', uniqueCpf)

    /** @ngInject */
    function uniqueCpf($http) {
        var toId;
        var cadastro;
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, elem, attr, ctrl, cpf) {
                scope.$watch(attr.ngModel, function (value) {
                    if (toId) clearTimeout(toId);

                    if (value == null) {
                        return;
                    }

                    toId = setTimeout(function () {
                        cadastro = {
                            value: value
                        };

                        $http.post("../api/verifica-cpf", cadastro).success(function (data) {
                            ctrl.$setValidity('uniqueCpf', data.isValid);
                            ctrl.$setTouched();
                        });

                        cpf = cadastro.value;

                        if (cpf != undefined && cpf.length >= 11) {

                            cpf = cpf.replace(/[\.-]/g, "");

                            var numeros, digitos, soma, i, resultado, digitos_iguais;
                            digitos_iguais = 1;

                            for (i = 0; i < cpf.length - 1; i++)
                                if (cpf.charAt(i) != cpf.charAt(i + 1)) {
                                    digitos_iguais = 0;
                                    break;
                                }
                            if (!digitos_iguais) {
                                numeros = cpf.substring(0, 9);
                                digitos = cpf.substring(9);
                                soma = 0;
                                for (i = 10; i > 1; i--)
                                    soma += numeros.charAt(10 - i) * i;
                                resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                                if (resultado != digitos.charAt(0))
                                    return false;
                                numeros = cpf.substring(0, 10);
                                soma = 0;
                                for (i = 11; i > 1; i--)
                                    soma += numeros.charAt(11 - i) * i;
                                resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                                if (resultado != digitos.charAt(1))
                                    return false;
                                return true;

                                ctrl.$setValidity('validCpf', cpf);
                                ctrl.$setTouched();

                            } else
                                return false;
                        }
                    }, 200);
                })
            }
        }
    }

}());