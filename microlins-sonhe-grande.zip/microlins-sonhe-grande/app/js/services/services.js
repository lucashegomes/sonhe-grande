(function () {
    'use strict';

    angular
        .module('SonheGrande')
        .factory('SSO', SSO)
        .factory('API', API)

    /** @ngInject */
    function SSO($http) {

        var serviceBase = 'https://sso.moveedu.net/';
        var obj = {};

        obj.get = function (q) {
            return $http.get(serviceBase + q).then(function (results) {
                return results.data;
            });
        };

        return obj;
    }

    function API($http) {

        var serviceBase = '../api/';
        var obj = {};

        obj.get = function (q) {
            return $http.get(serviceBase + q).then(function (results) {
                return results.data;
            });
        };

        obj.post = function (q, object) {
            return $http.post(serviceBase + q, object, {
                'Content-Type': 'application/x-www-form-urlencoded'
            }).then(function (results) {
                return results.data;
            });
        };

        return obj;
    }

}());