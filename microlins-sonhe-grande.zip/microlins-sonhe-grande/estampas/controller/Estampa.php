<?php

$classe = new Models\Alunos;

$aluno = $classe->RetornaAluno($aluno);

$estampa = $classe->Estampa($aluno->id);

$dadosAluno = array();
$dadosEstampa = array();

foreach ($aluno as $key => $value) {
    $dadosAluno[$key] = $value;
}

foreach ($estampa as $key => $value) {
    $dadosEstampa[$key] = $value;

}

$pageURL = 'https';
$pageURL .= "://";
$pageURL .= "www.";
$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];

// echo "<pre>";
// var_dump($dadosAluno);
// die;

require_once WWW_ROOT . '/Lib/smarty/Smarty.class.php';
$smarty = new Smarty();
$smarty->setTemplateDir('view/');
$smarty->setCompileDir('view/templates_c');

$smarty->assign('description', $estampa->titulo);
$smarty->assign('url', $pageURL);
$smarty->assign('aluno', @$dadosAluno);
$smarty->assign('estampa', @$dadosEstampa);
$smarty->assign('title', $estampa->titulo);
$smarty->assign('image', 'https://www.' . $_SERVER["SERVER_NAME"] . '/app/images/banner-to-share.png');
$smarty->display('estampa.tpl');
