<?php

$data = json_decode(file_get_contents("php://input"));

if (isset($_COOKIE[$data->id])) {
    $arrayName = array('erro' => 1 );
} else {
    $arrayName = array('sucesso' => 1);
    setcookie($data->id, $data->codigo);
    
    $cadastro = new Models\Alunos;
    $voto = $cadastro->InsertVoto($data);
}

header('Content-Type: application/json');
echo json_encode($arrayName);
