<?php
$data = json_decode(file_get_contents("php://input"));
$login = new Models\Alunos;

$ret = array('data' => $login->LoginAdmin($data));

header('Content-Type: application/json');

echo json_encode($ret);
