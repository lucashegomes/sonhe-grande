<?php
 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
ini_set("allow_url_fopen", 1);
 
$data = json_decode(file_get_contents("php://input"));
$aluno = new Models\Alunos;

$cadastro = $aluno->Login($data);
 
if(isset($cadastro) && $data->senha != 1){
    if(isset($cadastro->id)){
        $estampa = $aluno->Estampa($cadastro->id);
        $ret = array('cad' => $cadastro, 'estampa' => $estampa);
    }else{
        $ret = null;
    }
}else if(isset($cadastro) && $data->senha == 1){
 
    require_once 'Lib/smarty/Smarty.class.php';
 
    $email = base64_encode($cadastro->email);
    
    $link = "//" . $_SERVER["SERVER_NAME"]."/redefinir-senha/" . $email;
 
    $smarty = new Smarty();
    $smarty->setTemplateDir('Templates');
    $smarty->setCompileDir('Templates/Templates_c/');
    $smarty->assign('cadastro', @$cadastro);
    $smarty->assign('link', @$link);
    $output = $smarty->fetch("gera-link-alterar-senha.html");
 
    $nomeDe = 'MICROLINS - SONHE GRANDE';
    $emailCC = '';
    $emailBCC = 'lucas@marketmedia.com.br';
    $emailAssunto = 'Redefinição de Senha ';
 
    require_once 'Lib/phpmailer/class.phpmailer.php';
 
    $mailer = new PHPMailer();
    $mailer->IsSMTP();
    $mailer->SMTPDebug = 0;
    $mailer->SMTPAuth = true;
    $mailer->Host = 'smtp.moveedu.net';
    $mailer->Port = 587;
    $mailer->CharSet = 'utf-8';
    $mailer->Username = 'noreply@moveedu.net';
    $mailer->Password = 'Pr3pCur1';
    $mailer->From = 'noreply@moveedu.net';
    $mailer->FromName = $nomeDe;
    $mailer->AddAddress($cadastro->email);
 
    if ($emailCC) {
        $mailer->AddBCC($emailCC);
    }
 
    if ($emailBCC) {
        $mailer->AddBCC($emailBCC);
    }
 
    $mailer->IsHTML(true);
    $mailer->Subject = $emailAssunto;
    $mailer->Body = $output;
 
    $enviado = $mailer->Send();
 
    $mailer->ClearAllRecipients();
    $mailer->ClearAttachments();
 
    $ret = $cadastro;
}else{
    $ret = null;
}

header('Content-Type: application/json');
echo json_encode($ret);