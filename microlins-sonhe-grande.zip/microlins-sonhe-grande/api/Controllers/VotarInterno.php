<?php

if (isset($_COOKIE[$_POST['id']])) {
    $arrayName = array('erro' => 1 );
} else {
    $arrayName = array('sucesso' => 1);
    setcookie($_POST['id'], $_POST['codigo']);
    
    $cadastro = new Models\Alunos;
    $voto = $cadastro->InsertVotoInterno($_POST);
}

header('Content-Type: application/json');
echo json_encode($arrayName);
