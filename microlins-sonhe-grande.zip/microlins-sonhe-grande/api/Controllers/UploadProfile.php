<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use Lib\Intervention\Image\ImageManagerStatic as Image;

if (!empty($_FILES)) {

    $file_name = $_FILES['file']['name'];
    $file_tmp = $_FILES['file']['tmp_name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $imageName = date("YmdHis") . rand(1, 999) . '.jpg';

    if (!file_exists($_SERVER["DOCUMENT_ROOT"] . DS . 'uploads' . DS .  'profile')) {
        mkdir($_SERVER["DOCUMENT_ROOT"] . DS . 'uploads' . DS .  'profile', 0777);
    }

    $img = Image::make($file_tmp)->orientate()->encode('jpg', 75);

    $img->fit(200);
    $img->save($_SERVER["DOCUMENT_ROOT"] . DS . 'uploads' . DS .  'profile' . DS . $imageName);
    
    $image = array('image' => $imageName);
    $json = json_encode($image);

    echo $json;
} else {

    echo 'No files';

}

