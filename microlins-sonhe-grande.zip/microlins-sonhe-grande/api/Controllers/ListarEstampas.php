<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ini_set("allow_url_fopen", 1);
$data = json_decode(file_get_contents("php://input"));

$estampas = new Models\Alunos;

$ret = $estampas->ListarEstampas($data->limit);

header('Content-Type: application/json');

echo (json_encode($ret));
