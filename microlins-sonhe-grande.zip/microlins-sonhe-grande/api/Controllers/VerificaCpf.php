<?php

$data = json_decode(file_get_contents("php://input"));
$cadastro = new Models\Alunos;

$vCpf = $cadastro->VerificaCpf($data);

if (isset($vCpf->cpf)) {
    $ret = false;
} else {
    $ret = true;
}

$retorno = array('isValid' => $ret, 'value' => 'teste');

header('Content-Type: application/json');
echo json_encode($retorno);
