<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ini_set("allow_url_fopen", 1);
$data = json_decode(file_get_contents("php://input"));
$aluno = new Models\Alunos;

$estampa = $aluno->AprovarEstampa($data);
$cadastro = $aluno->RetornaCadastro($data->cadastro);
//var_dump($cadastro['email']);die;
echo json_encode($estampa);

if ($data->status == 1) {
    require_once 'Lib/smarty/Smarty.class.php';

    $smarty = new Smarty();
    $smarty->setTemplateDir('Templates');
    $smarty->setCompileDir('Templates/Templates_c/');
    $smarty->assign('estampa', @$data);
    $smarty->assign('cadastro', @$cadastro);
    $output = $smarty->fetch("email-aluno.html");

    $nomeDe = 'MICROLINS';
    $emailCC = '';
    $emailBCC = 'waltinho@marketmedia.com.br';
    $emailAssunto = 'Microlins - Sonhe Grande';

    require_once 'Lib/phpmailer/class.phpmailer.php';

    $mailer = new PHPMailer();
    $mailer->IsSMTP();
    $mailer->SMTPDebug = 0;
    $mailer->SMTPAuth = true;
    $mailer->Host = 'smtp.moveedu.net';
    $mailer->Port = 587;
    $mailer->CharSet = 'utf-8';
    $mailer->Username = 'noreply@moveedu.net';
    $mailer->Password = 'Pr3pCur1';
    $mailer->From = 'noreply@moveedu.net';
    $mailer->FromName = $nomeDe;
    $mailer->AddAddress($cadastro["email"]);

    if ($emailCC) {
        $mailer->AddBCC($emailCC);
    }

    if ($emailBCC) {
        $mailer->AddBCC($emailBCC);
    }

    $mailer->IsHTML(true);
    $mailer->Subject = $emailAssunto;
    $mailer->Body = $output;

    $enviado = $mailer->Send();

    $mailer->ClearAllRecipients();
    $mailer->ClearAttachments();
}