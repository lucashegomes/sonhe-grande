<?php

namespace Lib\Intervention\Image\Imagick\Commands;

class InvertCommand extends \Lib\Intervention\Image\Commands\AbstractCommand
{
    /**
     * Inverts colors of an image
     *
     * @param  \Lib\Intervention\Image\Image $image
     * @return boolean
     */
    public function execute($image)
    {
        return $image->getCore()->negateImage(false);
    }
}
