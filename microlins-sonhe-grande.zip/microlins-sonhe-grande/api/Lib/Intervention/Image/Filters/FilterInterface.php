<?php

namespace Lib\Intervention\Image\Filters;

interface FilterInterface
{
    /**
     * Applies filter to given image
     *
     * @param  \Lib\Intervention\Image\Image $image
     * @return \Lib\Intervention\Image\Image
     */
    public function applyFilter(\Lib\Intervention\Image\Image $image);
}
