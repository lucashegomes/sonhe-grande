<?php

namespace Lib\Intervention\Image\Gd\Commands;

use Lib\Intervention\Image\Size;

class GetSizeCommand extends \Lib\Intervention\Image\Commands\AbstractCommand
{
    /**
     * Reads size of given image instance in pixels
     *
     * @param  \Lib\Intervention\Image\Image $image
     * @return boolean
     */
    public function execute($image)
    {
        $this->setOutput(new Size(
            imagesx($image->getCore()),
            imagesy($image->getCore())
        ));

        return true;
    }
}
