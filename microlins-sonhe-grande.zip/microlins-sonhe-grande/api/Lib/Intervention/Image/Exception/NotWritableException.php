<?php

namespace Lib\Intervention\Image\Exception;

class NotWritableException extends ImageException
{
    # nothing to override
}
