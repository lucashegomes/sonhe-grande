<?php

namespace Lib\Intervention\Image\Exception;

class ImageException extends \RuntimeException
{
    # nothing to override
}
