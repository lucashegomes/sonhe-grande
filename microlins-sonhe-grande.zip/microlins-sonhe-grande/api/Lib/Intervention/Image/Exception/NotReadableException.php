<?php

namespace Lib\Intervention\Image\Exception;

class NotReadableException extends ImageException
{
    # nothing to override
}
