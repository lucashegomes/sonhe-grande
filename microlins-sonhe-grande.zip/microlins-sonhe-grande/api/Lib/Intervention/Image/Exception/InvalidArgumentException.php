<?php

namespace Lib\Intervention\Image\Exception;

class InvalidArgumentException extends ImageException
{
    # nothing to override
}
