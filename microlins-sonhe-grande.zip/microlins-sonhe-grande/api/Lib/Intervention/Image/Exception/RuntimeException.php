<?php

namespace Lib\Intervention\Image\Exception;

class RuntimeException extends ImageException
{
    # nothing to override
}
