<?php

namespace Lib\Intervention\Image\Exception;

class NotSupportedException extends ImageException
{
    # nothing to override
}
