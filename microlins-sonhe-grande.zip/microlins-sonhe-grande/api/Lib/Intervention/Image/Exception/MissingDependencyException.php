<?php

namespace Lib\Intervention\Image\Exception;

class MissingDependencyException extends ImageException
{
    # nothing to override
}
