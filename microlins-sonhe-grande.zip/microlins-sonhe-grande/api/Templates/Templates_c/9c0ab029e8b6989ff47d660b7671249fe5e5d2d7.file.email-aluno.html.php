<?php /* Smarty version Smarty-3.1.18, created on 2018-05-28 12:15:25
         compiled from "Templates\email-aluno.html" */ ?>
<?php /*%%SmartyHeaderCode:245715b0c188f1974a2-28713460%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9c0ab029e8b6989ff47d660b7671249fe5e5d2d7' => 
    array (
      0 => 'Templates\\email-aluno.html',
      1 => 1527519954,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '245715b0c188f1974a2-28713460',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5b0c188f1d15f5_86107103',
  'variables' => 
  array (
    'cadastro' => 0,
    'estampa' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b0c188f1d15f5_86107103')) {function content_5b0c188f1d15f5_86107103($_smarty_tpl) {?><!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Template</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

</head>

<body style="font-family: 'Open Sans', sans-serif; margin: 0; color: #000;">
  <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="border: none; background-color: #FFF;">
    <tr>
      <td>
        <img src="https://www.sonhegrandemicrolins.com.br/app/images/topo-email.jpg" alt="">
      </td>
    </tr>
    <tr>
      <td style="padding: 0 40px;">
        <h2 style="text-align: center; margin: 20px 0 0 0; font-size: 16px; border-bottom: 1px #666 solid; padding-bottom: 20px; color: #000;">
          <span style="font-family: 'Open Sans', Arial, sans-serif; font-size: 14px;">
            Olá <?php echo $_smarty_tpl->tpl_vars['cadastro']->value["nome"];?>
, sua estampa <?php echo $_smarty_tpl->tpl_vars['estampa']->value->titulo;?>
 foi aprovada.
          </span>
        </h2>
      </td>
    </tr>
    <tr>
      <td style="padding: 0 40px;">
        <div style="border: 1px #666 dotted; padding: 10px 15px; margin: 15px 0; color: #000;">
          <span style="font-family: 'Open Sans', Arial, sans-serif; font-size: 14px;">
            <b>Nome:</b> <?php echo $_smarty_tpl->tpl_vars['cadastro']->value["nome"];?>
</span>
        </div>
        <div style="border: 1px #666 dotted; padding: 10px 15px; margin: 15px 0; color: #000;">
          <span style="font-family: 'Open Sans', Arial, sans-serif; font-size: 14px;">
            <b>CPF:</b> <?php echo $_smarty_tpl->tpl_vars['cadastro']->value["cpf"];?>
</span>
        </div>
        <div style="border: 1px #666 dotted; padding: 10px 15px; margin: 15px 0; color: #000;">
          <span style="font-family: 'Open Sans', Arial, sans-serif; font-size: 14px;">
            <b>Unidade:</b> <?php echo $_smarty_tpl->tpl_vars['cadastro']->value["unidade"];?>
 (<?php echo $_smarty_tpl->tpl_vars['cadastro']->value["cidade"];?>
/<?php echo $_smarty_tpl->tpl_vars['cadastro']->value["estado"];?>
)</span>
        </div>
      </td>
    </tr>
    <tr>
      <td>
        <a href="https://www.sonhegrandemicrolins.com.br" target="_blank" title="Microlins - Sonhe Grande">
          <img src="https://www.sonhegrandemicrolins.com.br/app/images/rodape-email.jpg" alt="">
        </a>
      </td>
    </tr>
  </table>
</body>

</html><?php }} ?>
