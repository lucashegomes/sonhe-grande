<?php /* Smarty version Smarty-3.1.18, created on 2018-06-01 16:58:03
         compiled from "Templates\gera-link-alterar-senha.html" */ ?>
<?php /*%%SmartyHeaderCode:91905b11a142b802b0-27759309%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8765a763798ec1e2f94a90bc0af30a53c946e69c' => 
    array (
      0 => 'Templates\\gera-link-alterar-senha.html',
      1 => 1527883076,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '91905b11a142b802b0-27759309',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5b11a143082b38_65070976',
  'variables' => 
  array (
    'cadastro' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b11a143082b38_65070976')) {function content_5b11a143082b38_65070976($_smarty_tpl) {?><!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Template</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Exo+2:200,300,400,400i,500,600,700,800,900,900i" rel="stylesheet">

</head>

<body style="font-family: 'Open Sans', sans-serif; margin: 0; color: #000;">
    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="border: none; background-color: #FFF;">
        <tr>
            <td colspan="6" style="padding: 0 80px;">
                <img src="https://www.sonhegrandemicrolins.com.br/app/images/topo-email.jpg" alt="">
            </td>
        </tr>
        <tr>
            <td style="padding: 0 40px;">
                <h2 style="text-align: center; margin: 20px 0 0 0; font-size: 16px; border-bottom: 1px #666 solid; padding-bottom: 20px; color: #000;">
                    <span style="font-family: 'Exo 2'; font-size: 14px; font-weight: normal;">
                        Olá
                        <strong style="color:#923580;"><?php echo $_smarty_tpl->tpl_vars['cadastro']->value->nome;?>
</strong>! Para redefinir sua senha,
                        <a href="<?php echo $_smarty_tpl->tpl_vars['link']->value;?>
">CLIQUE AQUI</a>.
                    </span>
                </h2>
            </td>
        </tr>
        <tr>
        </tr>
        <tr>
            <td>
                <a href="https://www.sonhegrandemicrolins.com.br " target="_blank " title="Microlins - Sonhe Grande ">
                    <img src="https://www.sonhegrandemicrolins.com.br/app/images/rodape-email.jpg " alt=" ">
                </a>
            </td>
        </tr>
    </table>
</body>

</html><?php }} ?>
