<?php
namespace Models;

use Lib\RedBean\R as R;

class Alunos extends R
{
    public function __construct()
    {
    }

    public function CadastrarEstampa($data)
    {

        $cadastro = R::dispense('estampa');
        $cadastro->titulo = @$data->nomeEstampa;
        $cadastro->image = @$data->imgEstampa;
        $cadastro->cadastro = @$data->id;

        $id = R::store($cadastro);
        return $id;
    }
    
    public function ListarEstampas($limit)
    {
        $participantes = R::getAll("SELECT 
            c.id,
            e.titulo,
            e.image,
            e.votos,
            e.aprovada,
            c.nome,
            c.cidade,
            c.estado,
            c.unidade,
            c.codigo,
            c.tipo_acesso,
            c.foto
        FROM
            microlins_sonhegrande.estampa e
                LEFT JOIN
            microlins_sonhegrande.cadastros c ON c.id = e.cadastro
        WHERE e.aprovada = 1
        ORDER BY id DESC
        LIMIT ? , 3; ", [$limit]);

        return $participantes;

    }

    public function ListarEstampasVotadas($limit)
    {
        $participantes = R::getAll("SELECT 
            c.id,
            e.titulo,
            e.image,
            e.votos,
            e.aprovada,
            c.nome,
            c.cidade,
            c.estado,
            c.unidade,
            c.codigo,
            c.tipo_acesso,
            c.foto
        FROM
            microlins_sonhegrande.estampa e
                LEFT JOIN
            microlins_sonhegrande.cadastros c ON c.id = e.cadastro
        WHERE e.aprovada = 1
        ORDER BY votos DESC
        LIMIT ? , 3; ", [$limit]);

        return $participantes;

    }

    public function VerificaCpf($data)
    {
        if (isset($data->value)) {
            $data->value;
            $aluno = R::findOne('cadastros', ' cpf = ? ', [$data->value]);
            return $aluno;
        }
    }

    public function Login($data)
    {
        /*
        if(isset($data)){
            if ($data->email && isset($data->esqueciMinhaSenha)) {
                $amigo = R::findOne('cadastros', ' email = ?', [$data->email]);
            }else{
                $amigo = R::findOne('cadastros', ' email = ? && senha = ?', [$data->email, md5($data->senha)]);
            }
            return $amigo;
        }
        */

        if(isset($data)) {
            if ($data->email && $data->senha != 1) {
                $amigo = R::findOne('cadastros', ' email = ? && senha = ?', [$data->email, md5($data->senha)]);
            } else if($data->email){
                $amigo = R::findOne('cadastros', ' email = ?', [$data->email]);
            }

            return $amigo;
        }
    }

    public function Estampa($data)
    {
        if (isset($data)) {
            $amigo = R::findOne('estampa', ' cadastro = ?', [$data]);
            return $amigo;
        }
    }

    public function InsertVoto($data)
    {
        if (isset($data)) {
            $amigo = R::findOne('estampa', ' cadastro = ?', [$data->id]);

            $views = $amigo['votos'] + 1;

            $amigo->votos = $views;
            $id = R::store($amigo);
            return $id;
        }
    }

    public function InsertVotoInterno($data)
    {
        if (isset($data)) {
            $amigo = R::findOne('estampa', ' cadastro = ?', [$data['id']]);

            $views = $amigo['votos'] + 1;

            $amigo->votos = $views;
            $id = R::store($amigo);
            return $id;
        }
    }

    public function RetornaAluno($codigo)
    {
        $amigo = R::findOne('cadastros', ' codigo = ? ', [$codigo]);
        return $amigo;
    }

    public function RetornaEstampas()
    {
        $estampas = R::findAll('estampa', '', []);

        return $estampas;
    }

    public function RetornaCadastro($id)
    {

        $newCodigos = array();

        $participante = R::getAll("SELECT 
            c.id,
            c.nome,
            c.email,
            c.telefone,
            c.cpf,
            c.cidade,
            c.estado,
            c.unidade,
            c.codigo,
            c.foto,
            e.titulo,
            e.image,
            e.votos,
            e.aprovada
        FROM
            microlins_sonhegrande.estampa e
                LEFT JOIN
            microlins_sonhegrande.cadastros c ON c.id = e.cadastro
        WHERE c.id = :id order by c.id DESC", [':id' => $id]);

        foreach ($participante as $key => $value) {
            $newCodigos[] = $value;
        }

        return $newCodigos[0];
    }
    
    public function AprovarEstampa($data)
    {
        $estampa = R::findOne('estampa', ' id = ? ', [$data->id]);
        if ($estampa) {

            $estampa->aprovada = $data->status;
            $id = R::store($estampa);
            return $id;
        }

    }

    public function LoginAdmin($data)
    {
        if (isset($data)) {
            $usuario = R::findOne('usuarios', ' email = ? && senha = ?', [$data->username, md5($data->password)]);

            return $usuario;
        }
    }

    public function AtualizaPicProfile($data){

        $aluno = R::findOne('cadastros', ' id = ?', [$data->id]);
        if($aluno && $data->foto != null){
            $aluno->foto = $data->foto;
            $id = R::store($aluno);
            
            return $id;
        }
    }

    public function RedefinirSenha($data){
        
        $aluno = R::findOne('cadastros', ' email = ? ', [base64_decode($data->email)]);

        if ($aluno) {
            $aluno->senha = md5($data->senha);
            $id = R::store($aluno);
            return $id;
        }
    }
}
