<?php
namespace Models;

use Lib\RedBean\R as R;

class SSO extends R
{
    public function __construct()
    {
    }

    public function RealizaLogin($login, $senha)
    {
        $client = new \SoapClient('http://sso.moveedu.net/Usuarios.asmx?WSDL');

        $function = 'RealizaLogin';

        $arguments = array(
            'SenhaAplicacao' => "SCO3W1ZVN30VOHVKTQWQ",
            'Login' => $login,
            'Senha' => $senha,
        );

        $result = $client->RealizaLogin($arguments);

        return $result;
    }
}
