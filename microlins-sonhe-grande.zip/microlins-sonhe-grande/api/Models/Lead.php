<?php
namespace Models;

use Lib\RedBean\R as R;

class Lead extends R
{
    public function __construct()
    {
    }

    public function CadastrarLead($dados)
    {
        $client = new \SoapClient('http://leads.moveedu.net/LeadService.asmx?WSDL');

        $function = 'GravarLeadApp';

        $arguments = array(
            'Senha' => "5W3PGMPH",
            'CodigoEmitente' => $dados->code,
            'CampanhaID' => '664',
            'Nome' => $dados->nome,
            'Email' => $dados->email,
            'DDD' => $dados->ddd,
            'Telefone' => $dados->tel,
            'Comentario' => '',
            'OrigemID' => '152',
            'MidiaID' => '46',
            'MarcaId' => $dados->marca,
        );

        $result = $client->GravarLeadApp($arguments);

        return $result;
    }

    public function CadastrarLeadBd($data)
    {

        $upper = implode('', range('A', 'Z'));
        $lower = implode('', range('a', 'z'));
        $nums = implode('', range(0, 9));

        $alphaNumeric = $upper . $lower . $nums;
        $string = '';
        $len = 5;

        for ($i = 0; $i < $len; $i++) {
            $string .= $alphaNumeric[rand(0, strlen($alphaNumeric) - 1)];
        }

        $cadastro = R::dispense('cadastros');
        $cadastro->nome = @$data->nome;
        $cadastro->senha = md5($data->senha);
        $cadastro->leadId = @$data->lead;
        $cadastro->cpf = @$data->cpf;
        $cadastro->email = @$data->email;
        $cadastro->estado = @$data->estado;
        $cadastro->cidade = @$data->cidade;
        $cadastro->tipoAcesso = @$data->tipoAcesso;
        $cadastro->telefone = @$data->telefone;
        $cadastro->unidade = @$data->unidade;
        $cadastro->unidadeCode = @$data->code;
        $cadastro->foto = @$data->imgProfile;
        $cadastro->dataCadastro = date("Y-m-d H:i:s");

        $id = R::store($cadastro);

        $update = R::findOne('cadastros', ' id = ? ', [$id]);
        $update->codigo = @$id . '-' . $string;
        $idUpdate = R::store($update);

        return $id;
    }
}
