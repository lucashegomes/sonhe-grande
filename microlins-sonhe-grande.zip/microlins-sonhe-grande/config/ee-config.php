<?php 
define('DB_NAME', 'wizardestarwars_com_br');
define('DB_USER', 'wizard0sHtviAOSg'); 
define('DB_PASSWORD', 'jNd860QCY2vViFa');
define('DB_HOST', 'localhost');
?>